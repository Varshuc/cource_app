package com.course_management_app.course_app.dao;

public class Course {
}
