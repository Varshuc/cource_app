package com.cource_management_app.cource_app.controller;

import java.util.List;

public class CourseService {
    public <Course> List<Course> getCourses() {
        return null;
    }

    public <Course> Course getCourse(long l) {
        return null;
    }

    public <Course> Course addCourse(Course course) {
        return course;
    }

    public <Course> Course updateCourse(Course course) {
        return course;
    }

    public void deleteCourse(long l) {
    }
}
