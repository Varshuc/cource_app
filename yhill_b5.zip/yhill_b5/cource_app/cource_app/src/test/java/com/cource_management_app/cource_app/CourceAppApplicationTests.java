package com.cource_management_app.cource_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourceAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
